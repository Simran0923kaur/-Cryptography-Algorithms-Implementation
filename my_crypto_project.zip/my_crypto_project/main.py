import hashlib
import os # Although not directly used for key storage in this demo, good to have for potential enhancements

# Third-party library imports (cryptography)
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

# --- Cryptography Functions ---

def generate_aes_key():
    """
    Generates a new, secure AES key.
    This key is symmetric, meaning the same key is used for encryption and decryption.
    It's crucial to keep this key secret!
    """
    key = Fernet.generate_key()
    print(f"\nGenerated AES Key: {key.decode()}") # .decode() makes it a readable string
    print("IMPORTANT: Copy this key! You'll need it for both encryption and decryption.")
    return key

def encrypt_aes(plaintext, key):
    """
    Encrypts plaintext using the provided AES key.
    'Fernet' handles the complex AES encryption securely, including authentication.
    """
    try:
        f = Fernet(key)
        ciphertext = f.encrypt(plaintext.encode('utf-8')) # Encode plaintext to bytes
        print(f"\nOriginal Text: '{plaintext}'")
        print(f"Encrypted Text (AES): {ciphertext.decode()}") # Decode to string for display
        return ciphertext
    except Exception as e:
        print(f"Error encrypting: {e}. Make sure your key is valid.")
        return None

def decrypt_aes(ciphertext, key):
    """
    Decrypts ciphertext using the provided AES key.
    """
    try:
        f = Fernet(key)
        # Convert ciphertext string (from user input) to bytes for decryption
        decrypted_text = f.decrypt(ciphertext.encode('utf-8')) # Ensure consistent encoding
        print(f"\nCiphertext: '{ciphertext}'")
        print(f"Decrypted Text (AES): {decrypted_text.decode('utf-8')}") # Decode to string for display
        return decrypted_text
    except Exception as e:
        print(f"Error decrypting: {e}. Make sure the key is correct and the ciphertext is valid.")
        return None

def generate_rsa_key_pair():
    """
    Generates a new RSA public and private key pair.
    The private key must be kept secret. The public key can be shared.
    """
    # Generate a private key:
    #   - public_exponent: A small prime number, commonly 65537.
    #   - key_size: The length of the key in bits. 2048 is a common secure size.
    #   - backend: Specifies the cryptographic backend to use.
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )

    # Get the corresponding public key from the private key
    public_key = private_key.public_key()

    print("\n--- RSA Key Pair Generated ---")
    print("Private Key (KEEP SECRET!):")
    # For demonstration, we'll print a representation. In real apps, this is saved securely.
    print(f"  Type: {private_key.__class__.__name__}")
    print("Public Key (SHARE THIS!):")
    print(f"  Type: {public_key.__class__.__name__}")
    print("------------------------------")

    return private_key, public_key

def encrypt_rsa(plaintext, public_key):
    """
    Encrypts plaintext using the RSA public key.
    Only the corresponding private key can decrypt this.
    Uses OAEP padding for security.
    """
    try:
        # Convert plaintext to bytes
        plaintext_bytes = plaintext.encode('utf-8')

        # Encrypt using the public key with OAEP padding
        ciphertext = public_key.encrypt(
            plaintext_bytes,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()), # Mask Generation Function
                algorithm=hashes.SHA256(), # Hashing algorithm for padding
                label=None # Optional label, usually None
            )
        )
        print(f"\nOriginal Text: '{plaintext}'")
        print(f"Encrypted Text (RSA): {ciphertext.hex()}") # .hex() for readable string representation
        return ciphertext
    except Exception as e:
        print(f"Error encrypting with RSA: {e}. Ensure public key is valid and message is not too long for the key size.")
        return None

def decrypt_rsa(ciphertext_hex, private_key):
    """
    Decrypts ciphertext (hex string) using the RSA private key.
    """
    try:
        # Convert hex string ciphertext back to bytes
        ciphertext_bytes = bytes.fromhex(ciphertext_hex)

        # Decrypt using the private key with OAEP padding
        plaintext_bytes = private_key.decrypt(
            ciphertext_bytes,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        print(f"\nCiphertext (RSA): '{ciphertext_hex}'")
        print(f"Decrypted Text (RSA): {plaintext_bytes.decode('utf-8')}") # Decode bytes back to string
        return plaintext_bytes
    except Exception as e:
        print(f"Error decrypting with RSA: {e}. Make sure the private key is correct and ciphertext is valid.")
        return None

def hash_sha256(text):
    """
    Generates a SHA-256 hash (a unique fingerprint) of the given text.
    SHA-256 is used for data integrity: if the text changes even slightly,
    the hash will be completely different.
    """
    # We need to convert the text into bytes before hashing.
    # .encode() turns the string into a sequence of bytes.
    hashed_text = hashlib.sha256(text.encode('utf-8')).hexdigest() # Ensure consistent encoding
    print(f"\nOriginal Text: '{text}'")
    print(f"SHA-256 Hash: {hashed_text}")
    return hashed_text

# --- Main Interactive Program ---

def main():
    """
    Main function for the Cryptography Playground CLI.
    Provides an interactive menu for users to choose cryptographic operations.
    """
    print("---------------------------------------")
    print("  Welcome to the Cryptography Playground!  ")
    print("---------------------------------------")

    current_aes_key = None # This variable will store the AES key when generated
    current_rsa_private_key = None # Stores the RSA private key object
    current_rsa_public_key = None  # Stores the RSA public key object

    while True: # This loop keeps the menu running until you choose to exit
        print("\nChoose an option:")
        print("1. AES Encryption/Decryption")
        print("2. SHA-256 Hashing")
        print("3. Generate New AES Key")
        print("4. RSA Key Pair Generation")
        print("5. RSA Encryption/Decryption")
        print("6. Exit")

        choice = input("Enter your choice (1-6): ") # Corrected prompt to (1-6)

        if choice == '1':
            # AES Operations
            if current_aes_key is None:
                print("\nNo AES key loaded. Please generate a key first (Option 3).")
                continue

            aes_action = input("Do you want to (E)ncrypt or (D)ecrypt? (E/D): ").upper()
            if aes_action == 'E':
                plaintext = input("Enter the text to encrypt: ")
                encrypt_aes(plaintext, current_aes_key)
            elif aes_action == 'D':
                ciphertext = input("Enter the text to decrypt: ")
                decrypt_aes(ciphertext, current_aes_key)
            else:
                print("Invalid choice. Please enter 'E' or 'D'.")

        elif choice == '2':
            # SHA-256 Hashing
            text_to_hash = input("Enter the text to hash with SHA-256: ")
            hash_sha256(text_to_hash)

        elif choice == '3':
            # Generate AES Key
            current_aes_key = generate_aes_key()

        elif choice == '4':
            # RSA Key Pair Generation
            current_rsa_private_key, current_rsa_public_key = generate_rsa_key_pair()
            print("RSA keys are now loaded in memory for use.")

        elif choice == '5':
            # RSA Encryption/Decryption
            if current_rsa_public_key is None or current_rsa_private_key is None:
                print("\nNo RSA key pair loaded. Please generate keys first (Option 4).")
                continue

            rsa_action = input("Do you want to (E)ncrypt or (D)ecrypt? (E/D): ").upper()
            if rsa_action == 'E':
                plaintext = input("Enter the text to encrypt with RSA: ")
                # RSA can only encrypt messages up to a certain size (related to key_size and padding)
                # For 2048-bit RSA with OAEP, max plaintext is 214 bytes.
                # A simple check for demo purposes:
                if len(plaintext.encode('utf-8')) > 200: # Rough estimate, be safe
                    print("Warning: RSA plaintext too long. Please enter a shorter message (e.g., max ~200 characters).")
                    continue
                encrypt_rsa(plaintext, current_rsa_public_key)
            elif rsa_action == 'D':
                ciphertext_hex = input("Enter the RSA ciphertext (hex string) to decrypt: ")
                decrypt_rsa(ciphertext_hex, current_rsa_private_key)
            else:
                print("Invalid choice. Please enter 'E' or 'D'.")

        elif choice == '6':
            # Exit the program
            print("\nExiting Cryptography Playground. Goodbye!")
            break

        else:
            # Invalid input
            print("Invalid choice. Please enter a number between 1 and 6.")

# This ensures 'main()' is called only when the script is run directly
if __name__ == "__main__":
    main()
