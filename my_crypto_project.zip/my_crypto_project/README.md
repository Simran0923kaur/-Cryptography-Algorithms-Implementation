TITLE : Cryptography Algorithms Implementation 

⦁	Project Overview:
This project is a command-line interface (CLI) application developed in Python that demonstrates the fundamental principles and implementation of various cryptographic algorithms. It serves as a practical exploration into secure communication, data integrity, and confidentiality.

⦁	Objective:
 To implement popular cryptography algorithms (SHA-256, AES, RSA) to understand encryption, decryption, and hashing processes, thereby grasping core cryptography fundamentals and secure communication protocols.

⦁	Key Features
SHA-256 Hashing: 
           Generates a unique, fixed-size hash (digital fingerprint) of input text, primarily used for verifying data integrity.

AES (Advanced Encryption Standard) Symmetric Encryption: 
                          Encrypts and decrypts text using a single, shared secret key, ensuring data confidentiality.

RSA (Rivest–Shamir–Adleman) Asymmetric Encryption: 
                            Demonstrates public-key cryptography by generating a public/private key pair and using them for secure encryption and decryption.

Interactive Command-Line Interface: 
        Provides a user-friendly menu for selecting and performing cryptographic operations.

⦁	Technologies Used
Python 3.x: The core programming language for the application logic.

cryptography library: A robust and actively maintained Python library for cryptographic primitives, used for secure AES (via Fernet) and RSA implementations.

hashlib (Python Standard Library): Utilized for SHA-256 hashing.

⦁	Setup Instructions
To set up and run this project on your local machine, follow these steps:

1. Project Structure
Ensure your project directory has the following structure:

my_crypto_project/
├── main.py
├── requirements.txt
└── README.md

2. Create a Python Virtual Environment (Recommended)
It is highly recommended to use a virtual environment to manage project dependencies and avoid conflicts with other Python projects.

Open your terminal or command prompt, navigate to your my_crypto_project directory, and run:

python -m venv venv

3. Activate the Virtual Environment
Before installing dependencies or running the application, activate your virtual environment:

On Windows:

venv\Scripts\activate

On macOS / Linux:

source venv/bin/activate

(You should see (venv) at the beginning of your terminal prompt, indicating the environment is active.)

4. Install Dependencies
With your virtual environment activated, install the required Python libraries using pip:

pip install -r requirements.txt

(The requirements.txt file contains cryptography.)

5. Run the Application
Once all dependencies are installed, you can run the application:

python main.py

⦁	USAGE 
The application will present an interactive command-line menu. Follow the prompts to perform various cryptographic operations:

 1.AES Encryption/Decryption:

First, generate an AES key using Option 3. Copy this key carefully.

Then, select Option 1 to encrypt text using the generated key.

Use Option 1 again to decrypt the ciphertext, providing the same key.

2.SHA-256 Hashing:

Select Option 2. Enter any text to see its unique SHA-256 hash. Observe how even a minor change in the input text results in a drastically different hash.

RSA Key Pair Generation:

Select Option 4 to generate a public and private RSA key pair. These keys will be held in memory for subsequent RSA operations.

3.RSA Encryption/Decryption:

Ensure you have generated an RSA key pair using Option 4.

Select Option 5 to encrypt text using the RSA public key.

Use Option 5 again to decrypt the RSA ciphertext using the corresponding private key.

(** RSA has limitations on message size. For this demo, keep messages relatively short, e.g., under ~200 characters, to avoid encryption errors.**)

Exit: Select Option 6 to close the application.

⦁	Understanding the Algorithms
AES (Advanced Encryption Standard) - Symmetric Encryption
Concept: Uses a single, secret key for both encrypting (scrambling) and decrypting (unscrambling) data.

Confidentiality: Ensures that only parties possessing the secret key can read the encrypted information.

Implementation: This project uses Fernet from the cryptography library, which is an opinionated implementation of AES that also incorporates message authentication (HMAC-SHA256) to ensure the encrypted data has not been tampered with.

Key Management: The security of AES is entirely dependent on keeping the shared key absolutely secret.

output:
 (https://1drv.ms/i/c/cf88a2ac7e0d4c13/EaN5X2kJkT9MtBSJQtAowCQBecUFboKG2kMFs-Wh8EznEw?e=z2uqwj)

SHA-256 (Secure Hash Algorithm 256) - Hashing

Concept: A one-way mathematical function that takes an input (e.g., text, file) and produces a fixed-size string of characters (a "hash" or "message digest").

Integrity: Primarily used to verify data integrity. If even a single bit of the original data changes, the resulting SHA-256 hash will be completely different.

One-Way: It is computationally infeasible to reverse the hashing process to get the original input from the hash value.

Collision Resistance: It is extremely difficult to find two different inputs that produce the same hash value.

Use Cases: Verifying file downloads, storing password hashes (never store actual passwords!), digital signatures.

output:(https://1drv.ms/i/c/cf88a2ac7e0d4c13/ESl_JFQVnlhLvMrmQWPrAOsB_X5MXIYhO_Q5U38mGyo2YQ?e=wkHwre)
 (https://1drv.ms/i/c/cf88a2ac7e0d4c13/ES6ooB3fWdJMjioTdD7Wnl8BmdevNGAOjlts3ZdrK1KN_Q?e=8DGe8Q)


RSA (Rivest–Shamir–Adleman) - Asymmetric Encryption

Concept: Uses a pair of mathematically linked keys: a public key (which can be freely shared) and a private key (which must be kept secret).

Confidentiality: Data encrypted with the public key can only be decrypted by the corresponding private key.

Digital Signatures: Data "signed" with the private key can be verified by anyone using the corresponding public key, proving authenticity and non-repudiation.

Key Management: The security relies on the private key remaining secret, while the public key can be distributed widely.

Performance: RSA is computationally more intensive than AES and is typically used for encrypting small amounts of data (like session keys for symmetric encryption) or for digital signatures, rather than large files.

outputs :(https://1drv.ms/i/c/cf88a2ac7e0d4c13/Ec2-dgr0mcRBtaQwOQ3mszABXhy59rdBgOgplGYRsumxJQ?e=LA1VeF)
(https://1drv.ms/i/c/cf88a2ac7e0d4c13/ESyxHnBNnq1Akpc_w3w9zY0BFdP1FXZ35hta6HY8BBClpA?e=nkijFk)

Security Considerations

Key Security: In this demonstration, cryptographic keys are generated and held in memory. In real-world applications, keys must be securely stored (e.g., in hardware security modules, environment variables, or dedicated key management services) and never hardcoded or exposed in source code.

Input Validation: For simplicity, this demo does not extensively validate user input beyond basic type checks. A production-grade application would require robust input validation to prevent various attacks.

Purpose of Algorithms: It's important to understand the distinct purposes of hashing (integrity) versus encryption (confidentiality) and symmetric vs. asymmetric encryption. Each serves a specific role in securing data.

